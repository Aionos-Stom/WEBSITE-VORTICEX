'use client'

import { motion, useScroll, useTransform } from 'framer-motion'
import { useState, useEffect, useRef } from 'react'
import type { SiteConfigMap, Stat } from '@/types/database'
import Link from 'next/link'
import { TerminalTrigger } from '@/components/ui/InteractiveTerminal'

interface HeroSectionProps {
  config: SiteConfigMap
  stats: Stat[]
}

function TypewriterText({ text, delay = 0 }: { text: string; delay?: number }): JSX.Element {
  const [displayed, setDisplayed] = useState('')
  const [started, setStarted] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay)
    return () => clearTimeout(t)
  }, [delay])

  useEffect(() => {
    if (!started) return
    let i = 0
    const interval = setInterval(() => {
      setDisplayed(text.slice(0, i + 1))
      i++
      if (i >= text.length) clearInterval(interval)
    }, 45)
    return () => clearInterval(interval)
  }, [started, text])

  return (
    <span>
      {displayed}
      <motion.span
        animate={{ opacity: [1, 0, 1] }}
        transition={{ duration: 0.7, repeat: Infinity }}
        className="inline-block w-0.5 h-[1em] bg-[#E63946] ml-0.5 align-middle"
      />
    </span>
  )
}

const NAV_LINKS = [
  { href: '#sobre-mi', label: 'sobre_mi' },
  { href: '#servicios', label: 'servicios' },
  { href: '#arsenal', label: 'skills' },
  { href: '#misiones', label: 'proyectos' },
  { href: '#manifiesto', label: 'manifiesto' },
  { href: '#contacto', label: 'contacto' },
]

function getSocialLinks(config: SiteConfigMap) {
  return [
    config.github_url   ? { label: 'gh', href: config.github_url }   : null,
    config.linkedin_url ? { label: 'li', href: config.linkedin_url } : null,
    config.twitter_url  ? { label: 'tw', href: config.twitter_url }  : null,
  ].filter(Boolean) as Array<{ label: string; href: string }>
}

export function HeroSection({ config, stats }: HeroSectionProps): JSX.Element {
  const heroRef = useRef<HTMLElement>(null)
  const socialLinks = getSocialLinks(config)
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const yParallax = useTransform(scrollYProgress, [0, 1], [0, -80])
  const opacityParallax = useTransform(scrollYProgress, [0, 0.7], [1, 0])

  return (
    <section ref={heroRef} className="relative z-10 min-h-screen flex flex-col overflow-hidden">

      {/* Nav */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-20 flex items-center justify-between px-6 md:px-10 py-5 border-b border-[rgba(230,57,70,0.07)]"
      >
        <span className="font-mono-custom text-[#E63946] font-black text-lg tracking-wider">
          &gt; {config.hero_name.split(' ')[0]?.toLowerCase() ?? 'me'}_
        </span>
        <div className="hidden md:flex items-center gap-6">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-mono-custom text-xs text-[#6B5A5A] hover:text-[#E63946] transition-colors duration-200 tracking-wider"
            >
              {link.label}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-2">
          {socialLinks.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono-custom text-xs text-[#6B5A5A] hover:text-[#E63946] transition-colors border border-[rgba(230,57,70,0.12)] hover:border-[rgba(230,57,70,0.35)] px-2.5 py-1.5 rounded-md"
            >
              {s.label}
            </a>
          ))}
          <Link
            href="/admin"
            className="font-mono-custom text-xs text-[#6B5A5A] hover:text-[#E63946] transition-colors border border-[rgba(230,57,70,0.12)] hover:border-[rgba(230,57,70,0.35)] px-2.5 py-1.5 rounded-md"
          >
            admin
          </Link>
        </div>
      </motion.nav>

      {/* Hero content */}
      <motion.div
        style={{ y: yParallax, opacity: opacityParallax }}
        className="flex-1 flex items-center justify-center px-6 md:px-10 py-16"
      >
        <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">

          {/* Left — Text */}
          <div className="flex flex-col items-center lg:items-start text-center lg:text-left">

            {/* Status badge */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="flex items-center gap-2 mb-8"
            >
              <motion.span
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-1.5 h-1.5 rounded-full bg-[#E63946] shadow-[0_0_8px_#E63946]"
              />
              <span className="font-mono-custom text-[0.65rem] text-[#6B5A5A] tracking-[0.2em] uppercase">
                disponible — {config.hero_year}
              </span>
            </motion.div>

            {/* Name */}
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="font-mono-custom font-black leading-[0.9] mb-4"
              style={{
                fontSize: 'clamp(3rem, 8.5vw, 6.5rem)',
                background: 'linear-gradient(135deg, #ffffff 0%, #E63946 60%, #9B1D20 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                filter: 'drop-shadow(0 0 40px rgba(230,57,70,0.2))',
              }}
            >
              {config.hero_name}
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55 }}
              className="font-mono-custom font-semibold text-[#6B5A5A] mb-3 tracking-wide"
              style={{ fontSize: 'clamp(0.8rem, 1.8vw, 1rem)' }}
            >
              Arquitecto de Software &amp; Defensor Digital
            </motion.p>

            {/* Typewriter */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.75 }}
              className="font-mono-custom text-sm md:text-base text-[#E63946] mb-5 tracking-wide min-h-[1.8em]"
            >
              <TypewriterText text={config.hero_subtitle} delay={900} />
            </motion.div>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9 }}
              className="text-sm text-[#6B5A5A] mb-8 max-w-md leading-relaxed"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Donde la seguridad es el cimiento, el diseño es la religión y el rendimiento es innegociable.
              Construyo desde una premisa simple: pensar como atacante para construir como artesano.
            </motion.p>

            {/* Tags */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.05 }}
              className="flex flex-wrap gap-2 mb-8 justify-center lg:justify-start"
            >
              {['Full Stack', 'Cybersecurity', 'Cloud Arch', '3D Web'].map((tag) => (
                <span key={tag} className="tag-cyan">{tag}</span>
              ))}
            </motion.div>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="flex flex-wrap gap-3 justify-center lg:justify-start mb-6"
            >
              <a href="#misiones" className="btn-primary text-sm">ver proyectos</a>
              <a
                href="#certificados"
                className="btn-primary text-sm"
                style={{ borderColor: 'rgba(155,29,32,0.35)', color: '#C1121F' }}
              >
                ver certificados
              </a>
            </motion.div>

            {/* Interactive terminal */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.6 }}
              className="w-full flex justify-center lg:justify-start"
            >
              <TerminalTrigger config={config} />
            </motion.div>
          </div>

          {/* Right — Photo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.9, ease: [0.4, 0, 0.2, 1] }}
            className="flex justify-center"
          >
            <div className="relative">
              {/* Corner decorations */}
              <div className="absolute -top-3 -left-3 w-6 h-6 border-t-2 border-l-2 border-[rgba(230,57,70,0.5)]" />
              <div className="absolute -top-3 -right-3 w-6 h-6 border-t-2 border-r-2 border-[rgba(230,57,70,0.5)]" />
              <div className="absolute -bottom-3 -left-3 w-6 h-6 border-b-2 border-l-2 border-[rgba(230,57,70,0.5)]" />
              <div className="absolute -bottom-3 -right-3 w-6 h-6 border-b-2 border-r-2 border-[rgba(230,57,70,0.5)]" />

              {/* Photo container */}
              <div className="relative w-60 h-60 md:w-72 md:h-72 rounded-xl overflow-hidden border border-[rgba(230,57,70,0.2)] shadow-[0_0_60px_rgba(230,57,70,0.1),0_0_20px_rgba(155,29,32,0.08)]">
                {config.hero_photo_url ? (
                  <img
                    src={config.hero_photo_url}
                    alt={config.hero_name}
                    className="w-full h-full object-cover"
                    style={{ imageRendering: 'auto' }}
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-[rgba(230,57,70,0.04)] to-[rgba(155,29,32,0.04)] flex flex-col items-center justify-center gap-3">
                    <span className="text-5xl">🧑‍💻</span>
                    <span className="font-mono-custom text-xs text-[#6B5A5A]">{'// foto_pendiente'}</span>
                  </div>
                )}
                {/* Subtle scan line */}
                <motion.div
                  className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[rgba(230,57,70,0.3)] to-transparent"
                  animate={{ top: ['0%', '100%', '0%'] }}
                  transition={{ duration: 5, repeat: Infinity, ease: 'linear' }}
                />
              </div>

              {/* Side label */}
              <div className="absolute -right-10 top-1/2 -translate-y-1/2 rotate-90 origin-center">
                <span className="font-mono-custom text-[0.6rem] text-[#6B5A5A] tracking-[0.3em] uppercase whitespace-nowrap">
                  FULL STACK · SECURITY
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Stats bar */}
      {stats.length > 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5 }}
          className="relative z-10 border-t border-[rgba(230,57,70,0.07)] py-7 px-6 md:px-10"
        >
          <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
            {[...stats].sort((a, b) => a.sort_order - b.sort_order).slice(0, 4).map((stat, i) => (
              <motion.div
                key={stat.id}
                className="text-center"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.6 + i * 0.08 }}
              >
                <p
                  className="font-mono-custom font-black leading-none mb-1"
                  style={{
                    fontSize: 'clamp(1.6rem, 4vw, 2.5rem)',
                    background: i % 2 === 0
                      ? 'linear-gradient(135deg, #E63946, #FF1744)'
                      : 'linear-gradient(135deg, #9B1D20, #E63946)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                  }}
                >
                  {stat.value}{stat.suffix ?? ''}
                </p>
                <p className="font-mono-custom text-[0.6rem] text-[#6B5A5A] tracking-[0.15em] uppercase mt-1">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      ) : null}

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5"
      >
        <span className="font-mono-custom text-[0.55rem] text-[#6B5A5A] tracking-widest">SCROLL</span>
        <motion.div
          animate={{ y: [0, 8, 0], opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 1.8, repeat: Infinity }}
          className="w-px h-10 bg-gradient-to-b from-[#E63946] to-transparent"
        />
      </motion.div>
    </section>
  )
}
