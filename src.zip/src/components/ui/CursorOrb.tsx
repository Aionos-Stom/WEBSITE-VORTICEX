'use client'

import { useEffect, useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

export function CursorOrb(): JSX.Element {
  const cursorX = useMotionValue(-200)
  const cursorY = useMotionValue(-200)
  const isHoveringRef = useRef(false)
  const scaleMotion = useMotionValue(1)

  // Main dot — instant
  const dotX = useSpring(cursorX, { stiffness: 3000, damping: 60, mass: 0.01 })
  const dotY = useSpring(cursorY, { stiffness: 3000, damping: 60, mass: 0.01 })

  // Ring — fast, crisp
  const ringX = useSpring(cursorX, { stiffness: 700, damping: 40, mass: 0.12 })
  const ringY = useSpring(cursorY, { stiffness: 700, damping: 40, mass: 0.12 })

  const ringScale = useSpring(scaleMotion, { stiffness: 600, damping: 28 })

  useEffect(() => {
    const move = (e: MouseEvent): void => {
      cursorX.set(e.clientX)
      cursorY.set(e.clientY)
    }

    const over = (e: MouseEvent): void => {
      const target = e.target as HTMLElement
      const clickable = target.closest('a, button, [role="button"], input, select, textarea, label, [data-cursor]')
      if (clickable && !isHoveringRef.current) {
        isHoveringRef.current = true
        scaleMotion.set(1.8)
      } else if (!clickable && isHoveringRef.current) {
        isHoveringRef.current = false
        scaleMotion.set(1)
      }
    }

    window.addEventListener('mousemove', move)
    window.addEventListener('mouseover', over)
    return () => {
      window.removeEventListener('mousemove', move)
      window.removeEventListener('mouseover', over)
    }
  }, [cursorX, cursorY, scaleMotion])

  return (
    <>
      {/* Outer ring — fast, clean */}
      <motion.div
        style={{
          position: 'fixed',
          left: ringX,
          top: ringY,
          x: '-50%',
          y: '-50%',
          scale: ringScale,
          zIndex: 9997,
          pointerEvents: 'none',
          width: 32,
          height: 32,
          borderRadius: '50%',
          border: '1px solid rgba(230, 57, 70, 0.65)',
          boxShadow: '0 0 10px rgba(230,57,70,0.2)',
        }}
      />

      {/* Inner dot — instant */}
      <motion.div
        style={{
          position: 'fixed',
          left: dotX,
          top: dotY,
          x: '-50%',
          y: '-50%',
          zIndex: 9999,
          pointerEvents: 'none',
          width: 5,
          height: 5,
          borderRadius: '50%',
          background: '#E63946',
          boxShadow: '0 0 6px rgba(230,57,70,0.9), 0 0 14px rgba(230,57,70,0.5)',
        }}
      />
    </>
  )
}
