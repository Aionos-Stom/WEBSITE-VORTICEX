import type { Metadata } from 'next'
import './globals.css'
import { CursorOrb } from '@/components/ui/CursorOrb'
import { ScrollProgress } from '@/components/ui/ScrollProgress'
import { Toaster } from 'sonner'

export const metadata: Metadata = {
  title: 'Hi Soy Johan | Cybersecurity Developer and Software Developer',
  description: 'Senior Full Stack Engineer & Cybersecurity Architect. Building secure, immersive digital experiences.',
  keywords: ['cybersecurity', 'full stack', 'developer', 'portfolio', 'security', 'web'],
  authors: [{ name: 'Carlos Efrain Guillermo Rodriguez' }],
  openGraph: {
    title: 'Johan Torres | Owner System — Software Developer, Cybersecurity Developer',
    description: 'Senior Full Stack Engineer & Cybersecurity Architect.',
    type: 'website',
  },
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es" className="dark">
      <body className="bg-black text-slate-200 antialiased scanline-overlay">
        <ScrollProgress />
        <CursorOrb />
        {children}
        <Toaster
          theme="dark"
          toastOptions={{
            style: {
              background: 'rgba(8,2,4,0.97)',
              border: '1px solid rgba(230,57,70,0.18)',
              color: '#E8E0E0',
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: '0.8rem',
              borderRadius: '10px',
              boxShadow: '0 0 24px rgba(230,57,70,0.08)',
            },
          }}
        />
      </body>
    </html>
  )
}
